window.W = window.W || {};

/* 存檔系統
   三鐵律：任何新資料類型必須同時接上「寫入 collect()」「還原 apply()」「版本遷移 migrate()」，
   缺一即代表換裝置或改版後資料消失。新增欄位時三個函式都要動。
   儲存介質：只用 IndexedDB（不使用瀏覽器同步型儲存，避免 Safari 隱私模式問題）。 */
W.Save = (function() {

  var DB_NAME = 'wilds';
  var STORE = 'kv';
  var KEY = 'save';
  var VERSION = 4;

  var db = null;
  var ok = false;
  var reason = '\u5c1a\u672a\u521d\u59cb\u5316';
  var lastSaved = 0;
  var lastError = '';
  var autoT = 0;

  function open() {
    return new Promise(function(resolve) {
      var req;
      try {
        req = indexedDB.open(DB_NAME, 1);
      } catch (err) {
        ok = false;
        reason = 'indexedDB \u4e0d\u53ef\u7528';
        resolve(false);
        return;
      }
      req.onupgradeneeded = function(e) {
        var d = e.target.result;
        if (!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE);
      };
      req.onsuccess = function(e) {
        db = e.target.result;
        ok = true;
        reason = '\u6b63\u5e38';
        resolve(true);
      };
      req.onerror = function() {
        ok = false;
        reason = '\u958b\u555f\u5931\u6557\uff08\u53ef\u80fd\u662f\u96b1\u79c1\u700f\u89bd\uff09';
        resolve(false);
      };
    });
  }

  function put(val) {
    return new Promise(function(resolve) {
      if (!db) { resolve(false); return; }
      var tx, st, rq;
      try {
        tx = db.transaction(STORE, 'readwrite');
        st = tx.objectStore(STORE);
        rq = st.put(val, KEY);
      } catch (err) {
        lastError = String(err);
        resolve(false);
        return;
      }
      rq.onsuccess = function() { resolve(true); };
      rq.onerror = function() { lastError = 'put \u5931\u6557'; resolve(false); };
    });
  }

  function read() {
    return new Promise(function(resolve) {
      if (!db) { resolve(null); return; }
      var tx, st, rq;
      try {
        tx = db.transaction(STORE, 'readonly');
        st = tx.objectStore(STORE);
        rq = st.get(KEY);
      } catch (err) {
        lastError = String(err);
        resolve(null);
        return;
      }
      rq.onsuccess = function() { resolve(rq.result || null); };
      rq.onerror = function() { lastError = 'get \u5931\u6557'; resolve(null); };
    });
  }

  function remove() {
    return new Promise(function(resolve) {
      if (!db) { resolve(false); return; }
      var tx, rq;
      try {
        tx = db.transaction(STORE, 'readwrite');
        rq = tx.objectStore(STORE).delete(KEY);
      } catch (err) {
        resolve(false);
        return;
      }
      rq.onsuccess = function() { resolve(true); };
      rq.onerror = function() { resolve(false); };
    });
  }

  /* --- 鐵律一：寫入 --- */
  function collect() {
    return {
      v: VERSION,
      seed: W.CFG.SEED,
      savedAt: Date.now(),
      player: {
        wx: W.Player.wx,
        wy: W.Player.wy,
        faceX: W.Player.faceX,
        faceY: W.Player.faceY
      },
      inv: W.Inv.exportData(),
      taken: W.Res.exportTaken(),
      stats: W.Stats.exportData(),
      home: { wx: W.Player.homeWx, wy: W.Player.homeWy },
      gear: W.Craft.exportData(),
      builds: W.Build.exportData(),
      time: W.Time.exportData()
    };
  }

  /* --- 鐵律二：還原 --- */
  function apply(data) {
    if (!data) return false;
    data = migrate(data);
    if (!data) return false;

    var p = data.player;
    if (p && isFinite(p.wx) && isFinite(p.wy)) {
      W.Player.wx = p.wx;
      W.Player.wy = p.wy;
      W.Player.faceX = isFinite(p.faceX) ? p.faceX : 0;
      W.Player.faceY = isFinite(p.faceY) ? p.faceY : 1;
    }
    W.Inv.importData(data.inv);
    W.Res.importTaken(data.taken);
    W.Stats.importData(data.stats);
    W.Craft.importData(data.gear);
    W.Build.importData(data.builds);
    W.Time.importData(data.time);
    if (data.home && isFinite(data.home.wx) && isFinite(data.home.wy)) {
      W.Player.homeWx = data.home.wx;
      W.Player.homeWy = data.home.wy;
    }
    return true;
  }

  /* --- 鐵律三：版本遷移 --- */
  function migrate(data) {
    if (typeof data !== 'object') return null;
    var v = data.v || 0;

    if (v === 0) {
      data.v = 1;
      if (!data.player) data.player = { wx: W.CFG.START_WX, wy: W.CFG.START_WY };
      if (!data.inv) data.inv = {};
      if (!data.taken) data.taken = {};
      v = 1;
    }

    if (v === 1) {
      /* v1 沒有生存數值與出生點，補上預設值 */
      if (!data.stats) data.stats = { hp: 100, food: 100, stam: 100 };
      if (!data.home) data.home = null;
      data.v = 2;
      v = 2;
    }

    if (v === 2) {
      /* v2 沒有裝備與建造物，補上空值 */
      if (!data.gear) data.gear = { axe: false, pick: false };
      if (!data.builds) data.builds = [];
      data.v = 3;
      v = 3;
    }

    if (v === 3) {
      /* v3 沒有世界時鐘，從第一天早上開始 */
      if (!data.time) data.time = { t: 0.16, day: 1 };
      data.v = 4;
      v = 4;
    }

    /* 種子不同代表是另一個世界，座標與採集狀態不可沿用，只保留背包 */
    if (data.seed !== W.CFG.SEED) {
      data.player = null;
      data.taken = {};
      data.home = null;
      data.builds = [];
    }

    if (v > VERSION) return null;
    return data;
  }

  /* 產生快照並寫回本機，回傳「實際存下去的那一份」。
     雲端上傳必須用這一份，否則雲端會帶著另一個時間戳，
     下次比對就會誤判成雲端比較新而反覆下載。 */
  function snapshot() {
    if (!ok) return Promise.resolve(null);
    var d = collect();
    return put(d).then(function(r) {
      if (!r) return null;
      lastSaved = d.savedAt;
      if (W.Cloud) W.Cloud.markDirty();
      return d;
    });
  }

  function save() {
    return snapshot().then(function(d) { return !!d; });
  }

  function load() {
    if (!ok) return Promise.resolve(false);
    return read().then(function(d) {
      if (!d) return false;
      var r = apply(d);
      if (r) lastSaved = d.savedAt || 0;
      return r;
    });
  }

  /* 雲端下載後的套用路徑：一律先過 migrate，再進 apply，最後寫回本機 IDB。
     少了寫回這一步，重開 App 會被舊的本機檔蓋掉。 */
  function applyRemote(data) {
    var m = migrate(data);
    if (!m) return Promise.resolve(false);
    if (!apply(m)) return Promise.resolve(false);
    lastSaved = m.savedAt || Date.now();
    return put(m).then(function() { return true; });
  }

  function wipe() {
    W.Inv.clear();
    W.Res.clearTaken();
    W.Craft.clear();
    W.Build.clear();
    W.Time.clear();
    lastSaved = 0;
    return remove();
  }

  function tick(dt) {
    if (!ok) return;
    autoT += dt;
    if (autoT < W.CFG.AUTOSAVE_INTERVAL) return;
    autoT = 0;
    save();
  }

  function info() {
    return {
      ok: ok,
      reason: reason,
      lastSaved: lastSaved,
      lastError: lastError,
      version: VERSION
    };
  }

  return {
    open: open,
    save: save,
    load: load,
    wipe: wipe,
    tick: tick,
    info: info,
    collect: collect,
    snapshot: snapshot,
    apply: apply,
    migrate: migrate,
    applyRemote: applyRemote
  };
})();
