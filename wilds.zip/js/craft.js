window.W = window.W || {};

/* 合成系統。裝備狀態 gear 屬於必須存檔的資料類型，
   新增欄位時務必同步 save.js 的 collect / apply / migrate 三處。 */
W.Craft = (function() {

  var gear = { axe: false, pick: false };

  /* kind: tool = 取得裝備；place = 放置建造物；item = 產出物品
     need: 需要站在某種建造物旁（null 代表隨處可做） */
  var RECIPES = [
    { id: 'axe',  name: '\u77f3\u65a7',   icon: '\uD83E\uDE93', kind: 'tool',  cost: { wood: 3, stone: 2, fiber: 2 }, desc: '\u4f10\u6728\u7522\u91cf\uff0b2\uff0c\u653b\u64ca\uff0b7' },
    { id: 'pick', name: '\u77f3\u93ac',   icon: '\u26CF\uFE0F', kind: 'tool',  cost: { wood: 3, stone: 3, flint: 1 }, desc: '\u63a1\u77f3\u7522\u91cf\uff0b2' },
    { id: 'fire', name: '\u71df\u706b',   icon: '\uD83D\uDD25', kind: 'place', place: 0, cost: { wood: 5, stone: 3 }, desc: '\u65c1\u908a\u53ef\u4ee5\u70e4\u8089' },
    { id: 'wall', name: '\u6728\u7246',   icon: '\uD83E\uDDF1', kind: 'place', place: 1, cost: { wood: 4 }, desc: '\u963b\u64cb\u72fc\u7fa4' },
    { id: 'bed',  name: '\u7761\u888b',   icon: '\uD83D\uDECF\uFE0F', kind: 'place', place: 2, cost: { fiber: 8, hide: 3 }, desc: '\u91cd\u65b0\u8a2d\u5b9a\u71df\u5730' },
    { id: 'cook', name: '\u70e4\u8089',   icon: '\uD83C\uDF57', kind: 'item',  give: { cooked: 1 }, cost: { meat: 1 }, need: 0, desc: '\u9700\u8981\u7ad9\u5728\u71df\u706b\u65c1' }
  ];

  function list() { return RECIPES; }

  function canAfford(r) {
    var k;
    for (k in r.cost) {
      if (!r.cost.hasOwnProperty(k)) continue;
      if (W.Inv.count(k) < r.cost[k]) return false;
    }
    return true;
  }

  function costText(r) {
    var k, out = '';
    for (k in r.cost) {
      if (!r.cost.hasOwnProperty(k)) continue;
      if (out) out += '\u3001';
      out += W.Inv.label(k) + ' ' + r.cost[k];
    }
    return out;
  }

  function pay(r) {
    var k;
    for (k in r.cost) {
      if (!r.cost.hasOwnProperty(k)) continue;
      W.Inv.take(k, r.cost[k]);
    }
  }

  function byId(id) {
    var i;
    for (i = 0; i < RECIPES.length; i++) if (RECIPES[i].id === id) return RECIPES[i];
    return null;
  }

  /* 回傳字串代表失敗原因，回傳 true 代表成功 */
  function make(id) {
    var r = byId(id);
    if (!r) return '\u627e\u4e0d\u5230\u914d\u65b9';
    if (!canAfford(r)) return '\u6750\u6599\u4e0d\u8db3';

    if (r.need !== undefined && r.need !== null) {
      if (!W.Build.nearType(W.Player.wx, W.Player.wy, r.need, W.CFG.FIRE_RANGE)) {
        return '\u9700\u8981\u9760\u8fd1' + W.Build.nameOf(r.need);
      }
    }

    if (r.kind === 'tool') {
      if (gear[r.id]) return '\u5df2\u7d93\u64c1\u6709\u4e86';
      pay(r);
      gear[r.id] = true;
      return true;
    }

    if (r.kind === 'place') {
      var wx = W.Player.wx + W.Player.faceX * W.CFG.PLACE_DIST;
      var wy = W.Player.wy + W.Player.faceY * W.CFG.PLACE_DIST;
      if (!W.Build.canPlace(wx, wy)) return '\u9019\u88e1\u653e\u4e0d\u4e0b';
      pay(r);
      W.Build.add(r.place, wx, wy);
      W.Build.updateNear(W.Player.wx, W.Player.wy);
      if (r.place === W.Build.TYPE.BED) {
        W.Player.homeWx = wx;
        W.Player.homeWy = wy;
      }
      return true;
    }

    if (r.kind === 'item') {
      pay(r);
      var k;
      for (k in r.give) {
        if (!r.give.hasOwnProperty(k)) continue;
        W.Inv.add(k, r.give[k]);
      }
      return true;
    }

    return '\u672a\u77e5\u914d\u65b9\u985e\u578b';
  }

  function has(id) { return !!gear[id]; }

  function attackBonus() { return gear.axe ? W.CFG.AXE_ATK_BONUS : 0; }

  function yieldBonus(resType) {
    if (resType === 0 && gear.axe) return W.CFG.TOOL_YIELD_BONUS;
    if (resType === 1 && gear.pick) return W.CFG.TOOL_YIELD_BONUS;
    return 0;
  }

  function exportData() {
    return { axe: !!gear.axe, pick: !!gear.pick };
  }

  function importData(o) {
    gear.axe = !!(o && o.axe);
    gear.pick = !!(o && o.pick);
  }

  function clear() {
    gear.axe = false;
    gear.pick = false;
  }

  return {
    list: list,
    make: make,
    has: has,
    canAfford: canAfford,
    costText: costText,
    attackBonus: attackBonus,
    yieldBonus: yieldBonus,
    exportData: exportData,
    importData: importData,
    clear: clear
  };
})();
